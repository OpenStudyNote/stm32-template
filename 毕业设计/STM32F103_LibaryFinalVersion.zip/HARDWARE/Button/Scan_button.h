#ifndef _SCAN_BUTTON_H_
#define _SCAN_BUTTON_H_



#define btn1_id  1
#define btn2_id  2

#define uint16_t unsigned short
extern volatile unsigned short key_tick;
extern struct Button button1;
extern struct Button button2;

void BTN_PRESS_DOWN_Handler(void* btn);
void BTN_PRESS_UP_Handler(void* btn);
void BTN_PRESS_REPEAT_Handler(void* btn);
void BTN_SINGLE_Click_Handler(void* btn);
void BTN_DOUBLE_Click_Handler(void* btn);
void BTN_LONG_PRESS_START_Handler(void* btn);
void BTN_LONG_PRESS_HOLD_Handler(void* btn);

uint8_t read_button_GPIO(uint8_t button_id);
void scan_key(void);
#endif

