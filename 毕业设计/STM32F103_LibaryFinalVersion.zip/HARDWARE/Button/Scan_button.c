#include "multi_button.h"
#include "Scan_button.h"
#include "stdio.h"
#include "sys.h"
#include "usart.h"



volatile uint16_t key_tick = 0;

#define KEY1_Pin GPIO_Pin_7
#define KEY1_GPIO_Port GPIOE
#define KEY0_Pin GPIO_Pin_8
#define KEY0_GPIO_Port GPIOE

Button button1;
Button button2;


uint8_t read_button_GPIO(uint8_t button_id)
{
	// you can share the GPIO read function with multiple Buttons
	switch(button_id)
	{
		case btn1_id:
			return GPIO_ReadInputDataBit(KEY0_GPIO_Port, KEY0_Pin);
			break;
		case btn2_id:
			return GPIO_ReadInputDataBit(KEY1_GPIO_Port, KEY1_Pin);
			break;
		default:
			return 0;
			break;
	}
}
/*******************************************************************
  @brief  BTN_PRESS_DOWN_Handler
					�������»ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_PRESS_DOWN_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 press down\r\n");
			break;
		case btn2_id:
			printf("btn2 press down\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_PRESS_UP_Handler
					��������ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_PRESS_UP_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 press up\r\n");
			break;
		case btn2_id:
			printf("btn2 press up\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_PRESS_REPEAT_Handler
					�������»ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_PRESS_REPEAT_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 press repeat\r\n");
			break;
		case btn2_id:
			printf("btn2 press repeat\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_SINGLE_Click_Handler
					���������ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_SINGLE_Click_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 click\r\n");
			break;
		case btn2_id:
			printf("btn2 click\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_DOUBLE_Click_Handler
					����˫���ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_DOUBLE_Click_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 double click\r\n");
			break;
		case btn2_id:
			printf("btn2 double click\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_LONG_PRESS_START_Handler
					����������ʼ�ص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_LONG_PRESS_START_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 long press start\r\n");
			break;
		case btn2_id:
			printf("btn2 long press start\r\n");
			break;
		default:
			break;
	}
}

/*******************************************************************
  @brief  BTN_LONG_PRESS_HOLD_Handler
					�����������ֻص�����
  @param
					������� 
  @return   
					�� 
*******************************************************************/
void BTN_LONG_PRESS_HOLD_Handler(void* btn)
{
	Button *temp_button = (Button *)btn;
	switch(temp_button->button_id)
	{
		case btn1_id:
			printf("btn1 long press hold\r\n");
			break;
		case btn2_id:
			printf("btn2 long press hold\r\n");
			break;
		default:
			break;
	}
}
/*******************************************************************
  @brief scan_key()
				 ����ɨ�躯��  10ms����һ��
  @param
         �� 
  @return   
         �� 
*******************************************************************/
void scan_key()
{
	if(key_tick < TICKS_INTERVAL)return;
	key_tick = 0;
	
	button_ticks();
}




