#ifndef __EXTI_H
#define __EXIT_H	 

#include "sys.h"
#include "wea_esp8266.h"
			
void EXTIX_Init(void);//IO��ʼ��
		 					    
#endif

