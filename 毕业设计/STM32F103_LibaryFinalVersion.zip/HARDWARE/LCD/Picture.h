#ifndef __Picture_H__
#define __Picture_H__


extern const unsigned char Wendu[2048];
extern const unsigned char shidu[2056];
extern const unsigned char Light_IMG[2048];
extern const unsigned char IMG_Hpa[2056];
extern const unsigned char BBU[28568];
#endif


