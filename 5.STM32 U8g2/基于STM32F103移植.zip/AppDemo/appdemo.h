#ifndef _appdemo_H
#define _appdemo_H

#include "system.h"
#include "u8g2.h"


//��������
void app_demo(void);
void DrawLine_Test(u8g2_t *u8g2);
void process_Test(u8g2_t *u8g2);//��������ʾ
void font_Test(u8g2_t *u8g2);
void u8g2_DrawBox_Test(u8g2_t *u8g2);
void u8g2_DrawCircle_Test(u8g2_t *u8g2);
void u8g2_DrawEllipse_Test(u8g2_t *u8g2);
void Triangle_Test(u8g2_t *u8g2);
void DrawBox_Test(u8g2_t *u8g2);
void LCD_DrawClock(u8g2_t *u8g2,int x,int y,int r);//��ʱ�ӿ̶���
void Time_Test(u8g2_t *u8g2);


#endif
