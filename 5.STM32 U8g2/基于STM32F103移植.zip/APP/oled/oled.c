#include "oled.h"
#include "SysTick.h"

//��ֲOLED U8G2��Ļص�����
uint8_t u8x8_stm32_gpio_and_delay(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
	//printf("%s:msg = %d,arg_int = %d\r\n",__FUNCTION__,msg,arg_int);
	switch(msg)
	{
		case U8X8_MSG_DELAY_100NANO:		// delay arg_int * 100 nano seconds
			__NOP();
			break;
		case U8X8_MSG_DELAY_10MICRO:		// delay arg_int * 10 micro seconds
			for (uint16_t n = 0; n < 320; n++)
			{
				__NOP();
			}     
			break;
		case U8X8_MSG_DELAY_MILLI:			// delay arg_int * 1 milli second
			HAL_Delay(1);
			break;
		case U8X8_MSG_DELAY_I2C:		    // arg_int is the I2C speed in 100KHz, e.g. 4 = 400 KHz
			//delay 5us
			delay_us(5);						// arg_int=1: delay by 5us, arg_int = 4: delay by 1.25us

		case U8X8_MSG_GPIO_I2C_CLOCK:		// arg_int=0: Output low at I2C clock pin
			if(arg_int == 1) 
			{
				OLED_SCL_SET();
			}
			else if(arg_int == 0)
			{
				OLED_SCL_CLR();  
			}          
			break;							// arg_int=1: Input dir with pullup high for I2C clock pin
		case U8X8_MSG_GPIO_I2C_DATA:		// arg_int=0: Output low at I2C data pin
			//  printf("U8X8_MSG_GPIO_I2C_DATA:%d\r\n",arg_int);
			if(arg_int == 1) 
			{
				OLED_SDA_SET();
			}
			else if(arg_int == 0)
			{
				OLED_SDA_CLR();  
			}         
			break;							// arg_int=1: Input dir with pullup high for I2C data pin

		default:
			u8x8_SetGPIOResult(u8x8, 1);		// default return value
			break;
	}
	return 1;
}

//OLED GPIO��ʼ��
void oled_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	SCL_PORT_RCC_ENABLE;
	SDA_PORT_RCC_ENABLE;
	
	GPIO_InitStructure.Pin=SCL_PIN; 
    GPIO_InitStructure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_InitStructure.Pull=GPIO_PULLUP;          //����
    GPIO_InitStructure.Speed=GPIO_SPEED_FREQ_HIGH;     //����
    HAL_GPIO_Init(SCL_PORT,&GPIO_InitStructure);
	
	GPIO_InitStructure.Pin=SDA_PIN; 
    HAL_GPIO_Init(SDA_PORT,&GPIO_InitStructure);
	
	HAL_GPIO_WritePin(SCL_PORT,SCL_PIN,GPIO_PIN_SET);	
    HAL_GPIO_WritePin(SDA_PORT,SDA_PIN,GPIO_PIN_SET);
}