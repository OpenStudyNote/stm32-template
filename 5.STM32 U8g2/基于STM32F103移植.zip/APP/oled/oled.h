#ifndef _oled_H
#define _oled_H

#include "system.h"
#include "u8g2.h"

//IIC�ܽŶ���
#define SCL_PORT 				GPIOB   
#define SCL_PIN 				GPIO_PIN_6
#define SCL_PORT_RCC_ENABLE		__HAL_RCC_GPIOB_CLK_ENABLE()

#define SDA_PORT 				GPIOB   
#define SDA_PIN 				GPIO_PIN_7
#define SDA_PORT_RCC_ENABLE		__HAL_RCC_GPIOB_CLK_ENABLE()

//SCL�ܽ�
#define OLED_SCL_CLR() 	HAL_GPIO_WritePin(SCL_PORT,SCL_PIN,GPIO_PIN_RESET)
#define OLED_SCL_SET() 	HAL_GPIO_WritePin(SCL_PORT,SCL_PIN,GPIO_PIN_SET)
//SDA�ܽ�
#define OLED_SDA_CLR() 	HAL_GPIO_WritePin(SDA_PORT,SDA_PIN,GPIO_PIN_RESET)
#define OLED_SDA_SET() 	HAL_GPIO_WritePin(SDA_PORT,SDA_PIN,GPIO_PIN_SET)


//��������
void oled_init(void);
uint8_t u8x8_stm32_gpio_and_delay(U8X8_UNUSED u8x8_t *u8x8,
		U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int,
		U8X8_UNUSED void *arg_ptr);

#endif
