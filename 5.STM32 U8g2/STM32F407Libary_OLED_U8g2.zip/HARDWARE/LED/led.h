#ifndef __LED_H
#define __LED_H
#include "sys.h"
	
//LED�˿ڶ���
#define LED1 PFout(9)	    // D1 D1=0 ON D1=1 OFF
#define LED2 PFout(10)		// D2	 

void LED_Init(void);//��ʼ��			 				    
#endif
