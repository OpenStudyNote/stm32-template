1. 板载LED
2. 2.8寸LCD ILI9341
3. Touch触摸屏测试