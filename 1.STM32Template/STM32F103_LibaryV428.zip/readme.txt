Hardware 使用情况
1.  板载LED测试成功
2.  1.8 ST7735  LCD 软件SPI
3.  5个串口配置 正常使用
4.  OLED 0.96 软件IIC
5.  蜂鸣器 BEEP
6.  定时器timer 1s定时测试
7.  串口功能函数测试 USART
8.  DHT11温湿度传感器 单总线
9.  ADC MQ系列传感器测试
10. WWDG IWDG 窗口看门狗 独立看门狗
11 .SYN6288 语音播报模块
12. BMP280 气体压强传感器配置 软件IIC 
13. AHT10 温湿度传感器配置 软件IIC 
14. ST7735   TFT显示  传感器数据，图片，汉字，字符串等显示

Version2022.0222 


Version2022.0428
更新代码结构后期添加模块驱动 