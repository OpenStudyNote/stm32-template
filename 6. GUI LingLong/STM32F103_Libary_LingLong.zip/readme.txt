Hardware
1. 板载LED
2. 1.8 ST7735  LCD
3.STM32F103ZET6 5个串口正常使用
4.oled 0.96 iic
5. beep
6. 定时器timer
7. 串口usart
8.DHT11
9.adc
10.WWDG IWDG 窗口看门狗 独立看门狗
11.机智云配网 使用timer3 usart3 配置没有问题
12 .syn6288 语音播报
13.
