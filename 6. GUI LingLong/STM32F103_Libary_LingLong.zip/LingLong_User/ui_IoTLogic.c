#include "ui_IoTLogic.h"

/*
    reference
    llButton *btn = info.sender
    llImage *img = info.sender
    llText *txt = info.receiver
    llCheckBox *cb = info.sender
    llLineEdit *le = info.sender
    llSlider *slider = info.sender
    llProgressBar *progress = info.receiver
*/

/*user action code,don't delete this line*/

void ui_IoTLogicInit(void)
{
    
}

void ui_IoTLogicLoop(void)
{
    
}

void ui_IoTLogicQuit(void)
{
    
}


