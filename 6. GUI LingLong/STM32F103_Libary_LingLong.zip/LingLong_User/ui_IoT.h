#ifndef _UI_IOT_H_
#define _UI_IOT_H_

#ifdef __cplusplus
extern "C" {
#endif

void ui_IoTInit(void);

void ui_IoTLoop(void);

void ui_IoTQuit(void);

#ifdef __cplusplus
}
#endif

#endif //_UI_IOT_H_

