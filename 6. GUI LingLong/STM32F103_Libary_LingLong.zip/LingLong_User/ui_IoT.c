#include "ui_IoT.h"
#include "ui_IoTLogic.h"
#include "LL_General.h"
#include "LL_Gui.h"
#include "LL_Linked_List.h"
#include "LL_Timer.h"
#include "LL_ButtonEx.h"


void ui_IoTInit(void)
{
    //背景
    llBackgroundQuickCreate(ID_BACKGROUND,LL_MONITOR_WIDTH,LL_MONITOR_HEIGHT,true,RGB888(0x00007f),0);

    //文本
    llTextQuickCreate(ID_TEXT_0,ID_BACKGROUND,20,130,93,22,(uint8_t *)"2022-0202-dele",FONT_LIB_C_ARIAL_9,RGB888(0xaa0000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_0,true);

    //文本
    llTextQuickCreate(ID_TEXT_1,ID_BACKGROUND,0,10,49,30,(uint8_t *)"Temp",FONT_LIB_C_ARIAL_9,RGB888(0x00007f),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_1,true);

    //文本
    llTextQuickCreate(ID_TEXT_2,ID_BACKGROUND,70,10,49,30,(uint8_t *)"Hum",FONT_LIB_C_ARIAL_9,RGB888(0x00007f),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_2,true);

    llQRCodeQuickCreate(ID_QRCODE_0,ID_BACKGROUND,20,40,(uint8_t *)"",RGB888(0x000000),RGB888(0xffffff),0,0,1,4,false);
    nQRCodeSetEnabled(ID_QRCODE_0,true);

    ui_IoTLogicInit();
}

void ui_IoTLoop(void)
{
    ui_IoTLogicLoop();
}

void ui_IoTQuit(void)
{
    ui_IoTLogicQuit();
}

