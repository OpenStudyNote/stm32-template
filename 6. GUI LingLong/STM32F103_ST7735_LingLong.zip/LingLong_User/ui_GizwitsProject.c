#include "ui_GizwitsProject.h"
#include "ui_GizwitsProjectLogic.h"
#include "LL_General.h"
#include "LL_Gui.h"
#include "LL_Linked_List.h"
#include "LL_Timer.h"
#include "LL_ButtonEx.h"


void ui_GizwitsProjectInit(void)
{
    //背景
    llBackgroundQuickCreate(ID_BACKGROUND,LL_MONITOR_WIDTH,LL_MONITOR_HEIGHT,true,RGB888(0xffffff),0);

    //文本
    llTextQuickCreate(ID_TEXT_0,ID_BACKGROUND,10,0,40,20,(uint8_t *)"温度",FONT_LIB_C_SIMHEI_10,RGB888(0x000000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_0,true);

    //文本
    llTextQuickCreate(ID_TEXT_1,ID_BACKGROUND,10,30,37,20,(uint8_t *)"湿度",FONT_LIB_C_SIMHEI_10,RGB888(0x000000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_1,true);

    //文本
    llTextQuickCreate(ID_TEXT_2,ID_BACKGROUND,10,60,76,21,(uint8_t *)"光照强度",FONT_LIB_C_SIMHEI_10,RGB888(0x000000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_2,true);

    //文本
    llTextQuickCreate(ID_TEXT_3,ID_BACKGROUND,10,100,77,19,(uint8_t *)"大气压强",FONT_LIB_C_SIMHEI_10,RGB888(0x000000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_3,true);

    //文本
    llTextQuickCreate(ID_TEXT_4,ID_BACKGROUND,10,140,113,16,(uint8_t *)"BBU 2022 IoT",FONT_LIB_C_SIMHEI_10,RGB888(0x000000),RGB888(0xffffff),llAlignHLeft,llAlignVTop,0,0,false,false,false);
    nTextSetEnabled(ID_TEXT_4,true);
	

    ui_GizwitsProjectLogicInit();
}

void ui_GizwitsProjectLoop(void)
{
    ui_GizwitsProjectLogicLoop();
}

void ui_GizwitsProjectQuit(void)
{
    ui_GizwitsProjectLogicQuit();
}

