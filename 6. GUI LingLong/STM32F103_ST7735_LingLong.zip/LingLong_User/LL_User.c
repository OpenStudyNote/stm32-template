#include "LL_User.h"
#include "ui_GizwitsProject.h"
#include "SimHei_10.h"

uint8_t userPageMax=PAGE_MAX;
uint8_t userFontLibTotalNum=FONT_LIB_TOTAL_NUM;

llFontLib userFontLibList[FONT_LIB_TOTAL_NUM]={
    {typeCFile,"SimHei_10",10,&SimHei_10_Lib}
};

void (*pageInitFunc[PAGE_MAX])(void);
void (*pageLoopFunc[PAGE_MAX])(void);
void (*pageQuitFunc[PAGE_MAX])(void);

void llUserInit(void)
{
    pageInitFunc[0]=ui_GizwitsProjectInit;

    pageLoopFunc[0]=ui_GizwitsProjectLoop;

    pageQuitFunc[0]=ui_GizwitsProjectQuit;
};

uint16_t llUserGetAngle(void)
{
    return LL_LCD_ANGLE;
}
