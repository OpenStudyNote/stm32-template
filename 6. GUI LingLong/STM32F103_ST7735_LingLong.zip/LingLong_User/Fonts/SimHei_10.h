#ifndef _SIMHEI_10_H_
#define _SIMHEI_10_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "LL_General.h"

extern llLatticeLibraryInfo SimHei_10_Lib;

#ifdef __cplusplus
}
#endif

#endif // _SIMHEI_10_H_
