#ifndef _ARIAL_9_H_
#define _ARIAL_9_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "LL_General.h"

extern llLatticeLibraryInfo Arial_9_Lib;

#ifdef __cplusplus
}
#endif

#endif // _ARIAL_9_H_
