#ifndef _UI_GIZWITSPROJECT_H_
#define _UI_GIZWITSPROJECT_H_

#ifdef __cplusplus
extern "C" {
#endif

void ui_GizwitsProjectInit(void);

void ui_GizwitsProjectLoop(void);

void ui_GizwitsProjectQuit(void);

#ifdef __cplusplus
}
#endif

#endif //_UI_GIZWITSPROJECT_H_

