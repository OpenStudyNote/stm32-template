Hardware 使用情况
1.  板载LED测试成功
2.  1.8 ST7735  LCD 软件SPI
3.  5个串口配置 正常使用
4.  OLED 0.96 软件IIC
5.  蜂鸣器 BEEP
6.  定时器timer 1s定时测试
7.  串口功能函数测试 USART
8.  DHT11温湿度传感器 单总线
9.  ADC MQ系列传感器测试
10. WWDG IWDG 窗口看门狗 独立看门狗
11. 机智云配网 使用TIMER3 USART3配置成功
12 .SYN6288 语音播报模块
13. BMP280 气体压强传感器配置 软件IIC 
14. AHT10 温湿度传感器配置 软件IIC 
15. 机智云 上报传感器数据 NTP 网络时间获取
16. ST7735   TFT显示  传感器数据，图片，汉字，字符串等显示


案例
1.LingLong GUI 测试程序