#include "AHT10.H"

u8 ACK,DATA[6];

void AHT_I2C_UserConfig(void){
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin   = SDA|SCL;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(I2C_Prot,&GPIO_InitStructure);
}
void AHT_I2C_SDA_Mode(u8 addr){
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	if(addr){ //1 OUT
			
		GPIO_InitStructure.GPIO_Pin   = SDA;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
		GPIO_Init(I2C_Prot,&GPIO_InitStructure);	
	}
	else{     //0 INPUT
		
		GPIO_InitStructure.GPIO_Pin   = SDA;
		GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
		GPIO_Init(I2C_Prot,&GPIO_InitStructure);
	}
}
void AHT_I2C_Start(void){
	
	AHT_I2C_SDA_Mode(OUT);
	
	SCL_High;
	SDA_High;
	delay_us(5);
	
	SDA_Low;
	delay_us(5);
	SCL_Low;
}
void AHT_I2C_Stop(void){
	
	AHT_I2C_SDA_Mode(OUT);
	
	SDA_Low;
	delay_us(5);
	SCL_High;
	delay_us(5);
	SDA_High;
	delay_us(5);
}
u8 AHT_I2C_Write_Ack(void){
	
	u8 TimeAck = RESET;
	
	AHT_I2C_SDA_Mode(INPUT);
	
	SCL_High;
	delay_us(2);
	
	while(GPIO_ReadInputDataBit(I2C_Prot,SDA)){
		
		if(++TimeAck > 250){
			
			AHT_I2C_Stop();return 1;
		}
	}
	SCL_Low;
	delay_us(2);
	
	return 0;
}
void AHT_I2C_Write_Byte(u8 Data){
	
	SCL_Low;
	delay_us(2);
	
	for(u8 i=0;i<8;i++){
		
		AHT_I2C_SDA_Mode(OUT);
		
		if((Data<<i)&0x80) 
			SDA_High; 
		else 
			SDA_Low;
		
		SCL_High;
		delay_us(2);
		SCL_Low;
		delay_us(2);
	}
}
u8 AHT_I2C_Read_Data(void){
	
	u8 Data = RESET;
	
	for(u8 i=0;i<8;i++){
		
		AHT_I2C_SDA_Mode(INPUT); 
		
		SCL_High;
		delay_us(2);
		Data <<= 1; 
		
		if(GPIO_ReadInputDataBit(I2C_Prot,SDA) == SET){
			
			Data |= 0x01;
		}
		
		SCL_Low;
		delay_us(2);
	}
	
	return Data;
}
void AHT_I2C_Sende_Ack(u8 ack){
	
	AHT_I2C_SDA_Mode(OUT);
	
	if(ack)
		SDA_High;
	else
		SDA_Low;
	
	SCL_High;
	delay_us(2);
	SCL_Low;
	delay_us(2);
}



u8 AHT10_State(void){        //����0 ������ 1
	
	u8 ACK;
	
	AHT_I2C_Start();
	AHT_I2C_Write_Byte(AHT_WRITE);
	ACK = AHT_I2C_Write_Ack();
	AHT_I2C_Stop();
	
	return ACK;
}
void AHT10_Write_Init(void){ //	bit3 0 1
	
	AHT_I2C_Start();
	AHT_I2C_Write_Byte(AHT_WRITE);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0XE1);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0X08);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0X00);
	AHT_I2C_Write_Ack();
	AHT_I2C_Stop();
	delay_ms(40);
}
void AHT10_Write_Reset(void){
	
	AHT_I2C_Start();
	AHT_I2C_Write_Byte(AHT_WRITE);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0XBA);
	AHT_I2C_Write_Ack();
	AHT_I2C_Stop();
	delay_ms(20);
}
u8 AHT10_Read_Humi_Temp(float *HUMI, float *TEMP){ // 0�������� 1 ���ݴ���
	
	u32 humi = 0,temp = 0;
	
	AHT_I2C_Start();
	AHT_I2C_Write_Byte(AHT_WRITE);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0XAC);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0X33);
	AHT_I2C_Write_Ack();
	AHT_I2C_Write_Byte(0X00);
	AHT_I2C_Write_Ack();
	AHT_I2C_Stop();
	delay_ms(80);
	
	AHT_I2C_Start();
	AHT_I2C_Write_Byte(AHT_READ);
	AHT_I2C_Write_Ack();
	ACK = AHT_I2C_Read_Data();
	AHT_I2C_Sende_Ack(0); 		//0000 1000 BIT3 0
	
	if((ACK&0X08) == 0){
		
		AHT10_Write_Init();
	}
	if((ACK&0X80) == 0){ 	//bit7 1 0
		
		for(u8 i=0;i<5;i++){ // 0 1 2 3 4 5 ++i
			
			DATA[i] = AHT_I2C_Read_Data();
			
			if(i == 4)
				AHT_I2C_Sende_Ack(1);
			else
				AHT_I2C_Sende_Ack(0);
		}
		AHT_I2C_Stop();
		
		humi = (DATA[0]<<12)|(DATA[1]<<4)|(DATA[2]>>4);
		temp = ((DATA[2]&0X0F)<<16)|(DATA[3]<<8)|(DATA[4]);
		
		*HUMI = (humi * 100.0/1024/1024+0.5);
		*TEMP = (temp * 2000.0/1024/1024+0.5)/10.0-50;
		
		return 0;
	}
	
	AHT_I2C_Stop();
	return 1;
}
