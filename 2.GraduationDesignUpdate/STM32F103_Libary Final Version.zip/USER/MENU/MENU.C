#include <stdio.h>
#include "string.h"
#include "menu.h"
#include "USART.H"

//多级菜单的级数
#define		Menu_Select		3

//选项显示缓存区
char buf[100];

//按键标志初始值
uint8_t List_Number = 1;

//主次菜单切换
static uint8_t Menu_Change = 0;
//菜单刷新标志位
static uint8_t Menu_Refresh_Flag = 0;
//up/down控制按键标志位
static uint8_t UD_Action_Flag = 0;



/******************************************************************************
      * @brief	显示初始菜单，自己任意配置
      * @param  x,y 显示坐标
				fc 字的颜色
				bc 字的背景色
				sizey 字号
				mode:  0非叠加模式  1叠加模式
				Box_Height 选项框的高度
      * @retval 无
******************************************************************************/
void Display_Initial_Menu(u16 x,u16 y,u16 fc,u16 bc,u8 sizey,u8 mode,u8 Box_Height)
{
		printf(buf,"DISPLAY");
		//LCD_ShowString(x, y + ( Box_Height * 0 ), (uint8_t *)buf, fc, bc, sizey, mode);
		printf(buf,"VOICE");
		//LCD_ShowString(x, y + ( Box_Height * 1 ), (uint8_t *)buf, fc, bc, sizey, mode);
		printf(buf,"NOTICE");
		//LCD_ShowString(x, y + ( Box_Height * 2 ), (uint8_t *)buf, fc, bc, sizey, mode);
		printf(buf,"BATTERY");
		//LCD_ShowString(x, y + ( Box_Height * 3 ), (uint8_t *)buf, fc, bc, sizey, mode);
		printf(buf,"MEMORY");
		//LCD_ShowString(x, y + ( Box_Height * 4 ), (uint8_t *)buf, fc, bc, sizey, mode);
		printf(buf,"ABOUT");
		//LCD_ShowString(x, y + ( Box_Height * 5 ), (uint8_t *)buf, fc, bc, sizey, mode);
}



/******************************************************************************
	  * @brief	显示二级菜单，自己任意配置
	  * @param  x,y 显示坐标
				fc 字的颜色
				bc 字的背景色
				sizey 字号
				mode:  0非叠加模式  1叠加模式
				Box_Height 选项框的高度
	  * @retval 无
******************************************************************************/
void Display_Second_Menu(u16 x,u16 y,u16 fc,u16 bc,u8 sizey,u8 mode,u8 Box_Height)
{
	sprintf(buf,"DISPLAY");
	//LCD_ShowString(x, y + ( Box_Height * 0 ), (uint8_t *)buf, fc, bc, sizey, mode);
	sprintf(buf,"VOICE");
	//LCD_ShowString(x, y + ( Box_Height * 1 ), (uint8_t *)buf, fc, bc, sizey, mode);
	sprintf(buf,"NOTICE");
	//LCD_ShowString(x, y + ( Box_Height * 2 ), (uint8_t *)buf, fc, bc, sizey, mode);
	sprintf(buf,"BATTERY");
	//LCD_ShowString(x, y + ( Box_Height * 3 ), (uint8_t *)buf, fc, bc, sizey, mode);
}



/******************************************************************************
	  * @brief	显示三级菜单，自己任意配置
	  * @param  x,y 显示坐标
				fc 字的颜色
				bc 字的背景色
				sizey 字号
				mode:  0非叠加模式  1叠加模式
				Box_Height 选项框的高度
	  * @retval 无
******************************************************************************/
void Display_Third_Menu(void)
{
//	LCD_ShowPicture( 25, 15, 50, 50, BMP_1);	//1
//	LCD_ShowPicture( 95, 15, 50, 50, BMP_2);	//2
//	LCD_ShowPicture(175, 15, 50, 50, BMP_3);	//3

//	LCD_ShowPicture( 15, 95, 50, 50, BMP_4);	//4
//	LCD_ShowPicture( 95, 95, 50, 50, BMP_5);	//5
//	LCD_ShowPicture(175, 95, 50, 50, BMP_6);	//6

//	LCD_ShowPicture( 15, 175, 50, 50, BMP_7);	//7
//	LCD_ShowPicture( 95, 175, 50, 50, BMP_8);	//8
//	LCD_ShowPicture(175, 175, 50, 50, BMP_9);	//9
}



/******************************************************************************
  * @brief  注册up控制按键
  * @param  Menu_List：控制的列表项数目
  * @retval 无
  * eg:一个页面有6个选项，就让 Menu_List = 6
 ******************************************************************************/
void Button_Up_Click(uint8_t Menu_List)
{
	if (Button_Click_Event_1)
	{
		if (List_Number > 1)
			List_Number = List_Number - 1;
		else if (List_Number == 1)
			List_Number = Menu_List;
		else
			List_Number = List_Number;

		UD_Action_Flag = 2;
		//显示列表项标号
		LCD_ShowIntNum(220, 220, List_Number, 1, WHITE, BLACK, 16);
	}
}



/******************************************************************************
  * @brief  注册down控制按键
  * @param  控制的列表项数目
  * @retval 无
 ******************************************************************************/
void Button_Down_Click(uint8_t Menu_List)
{
	if (Button_Click_Event_2)
	{
		if (List_Number < Menu_List)
			List_Number = List_Number + 1;
		else if (List_Number == Menu_List)
			List_Number = 1;
		else
			List_Number = List_Number;

		UD_Action_Flag = 1;
		//显示列表项标号
		LCD_ShowIntNum(220, 220, List_Number, 1, WHITE, BLACK, 16);
	}
}



/******************************************************************************
  * @brief  注册菜单切入控制按键
  * @param  Desk_Num 菜单级数
  * @retval 无
  ****************************************************************************/
void Button_Menu_Enter(u8 Desk_Num)
{
	LCD_ShowIntNum(200,220,Menu_Change,1,WHITE,BLACK,16);
	//切入菜单，即进入下一级菜单
	if(Button_Click_Event_3)
	{
		Action_Menu_Change(0);		//载入下一级菜单动作
		Menu_Refresh_Flag = 1;

		if (Menu_Change < Desk_Num - 1)
			Menu_Change = Menu_Change + 1;
		else if (Menu_Change == Desk_Num - 1)
			Menu_Change = Desk_Num - 1;

		//显示菜单级标号
		LCD_ShowIntNum(220, 220, List_Number, 1, WHITE, BLACK, 16);
	}
}



/******************************************************************************
  * @brief  注册菜单切出控制按键
  * @param  Desk_Num 菜单级数
  * @retval 无
  ****************************************************************************/
void Button_Menu_Exit(u8 Desk_Num)
{
	LCD_ShowIntNum(200, 220, Menu_Change, 1, WHITE, BLACK, 16);
	//切出菜单，即返回上一级菜单
	if (Button_Click_Event_4)
	{
		Action_Menu_Change(1);		//载入上一级菜单的动作
		Menu_Refresh_Flag = 1;
		
		if (Menu_Change > 0)
			Menu_Change = Menu_Change - 1;
		if (Menu_Change < Desk_Num - 2)
			Menu_Change = 0;

		//显示菜单级标号
		LCD_ShowIntNum(220, 220, List_Number, 1, WHITE, BLACK, 16);
	}
}



/******************************************************************************
  * @brief  注册菜单切换控制按键搭配的动作
  * @param  select 事件标志
  * @retval 无
  ****************************************************************************/
u8 List = 0,List2 = 0;
void Action_Menu_Change(u8 select)
{
	switch (select)
	{
	case 0:
		switch (Menu_Change)
		{
		case 0:
			List = List_Number;
			List_Number = 1;
			LCD_Fill(0, 0, LCD_W, LCD_H, BLACK);
			break;
		case 1:
			List2 = List_Number;
			List_Number = 1;
			LCD_Fill(0, 0, LCD_W, LCD_H, BLACK);
			break;
		//case ...3级、4级菜单
		}
		break;

	case 1:
		switch (Menu_Change)
		{
		case 1:
			List_Number = List;
			LCD_Fill(0, 0, LCD_W, LCD_H, BLACK);
			break;
		case 2:
			List_Number = List2;	
			LCD_Fill(0, 0, LCD_W, LCD_H, BLACK);
			break;
		//case ...3级、4级菜单
		}
	default:
		break;
	}
	
}



/******************************************************************************
  * @brief  注册选项框上滑动作
  * @param  x1,y1 起始坐标
			x2,y2 终点坐标
			Box_Height 选项框的高度
			Menu_List	选项框个数
  * @retval 无
 ******************************************************************************/
void Action_Box_Up(u16 x1,u16 y1,u16 x2,u16 y2,uint8_t Menu_List, uint8_t Box_Height)
{
	if(UD_Action_Flag == 2)
	{
		UD_Action_Flag = 0;
		if(List_Number >= 1 && List_Number < Menu_List)
		{
			LCD_DrawLine(x1, y2+Box_Height*(List_Number), x2, y2+Box_Height*(List_Number), BLACK);
			LCD_DrawLine(x1, y1+Box_Height*(List_Number), x1, y2+Box_Height*(List_Number), BLACK);
			LCD_DrawLine(x2, y1+Box_Height*(List_Number), x2, y2+Box_Height*(List_Number), BLACK);
			printf("%d",List_Number);
		}
		if(List_Number == Menu_List)
		{
			LCD_DrawRectangle(x1, y1 + Box_Height*(0), x2, y2+Box_Height*(0), BLACK);
		}
	}
	
}



/******************************************************************************
  * @brief  注册选项框下滑动作
  * @param  x1,y1 起始坐标
			x2,y2 终点坐标
			Box_Height 选项框的高度
			Menu_List	选项框个数
  * @retval 无
 ******************************************************************************/
void Action_Box_Down(u16 x1, u16 y1, u16 x2, u16 y2, uint8_t Menu_List, uint8_t Box_Height)
{
	if (UD_Action_Flag == 1)
	{
		UD_Action_Flag = 0;
		if (List_Number > 1 && List_Number <= Menu_List)
		{
			LCD_DrawLine(x1, y1 + Box_Height * (List_Number - 2), x2, y1 + Box_Height * (List_Number - 2), BLACK);
			LCD_DrawLine(x1, y1 + Box_Height * (List_Number - 2), x1, y2 + Box_Height * (List_Number - 2), BLACK);
			LCD_DrawLine(x2, y1 + Box_Height * (List_Number - 2), x2, y2 + Box_Height * (List_Number - 2), BLACK);
			printf("%d", List_Number);
		}
		if (List_Number == 1)
		{
			LCD_DrawRectangle(x1, y1 + Box_Height * (Menu_List - 1), x2, y2 + Box_Height * (Menu_List - 1), BLACK);
		}
	}
}


/******************************************************************************
  * @brief  绘制选项框
  * @param  x1,y1 起始坐标
			x2,y2 终点坐标
			Box_Height 选项框的高度
			Menu_List	选项框个数
  * @retval 无
 ******************************************************************************/
void Draw_Option_Box(u16 x1, u16 y1, u16 x2, u16 y2, uint8_t Menu_List, uint8_t Box_Height)
{
	LCD_DrawRectangle(x1, y1 + Box_Height * (List_Number - 1), x2, y2 + Box_Height * (List_Number - 1), BLUE);
}



/******************************************************************************
  * @brief  注册菜单
  * @param  无
  * @retval 无
 ******************************************************************************/
void Menu_Display_Control(void)
{
	Button_Menu_Enter(Menu_Select);												//菜单等级控制
	Button_Menu_Exit(Menu_Select);

	switch (Menu_Change)
	{
		case 0:
			if (Menu_Refresh_Flag == 1)
			{
				Display_Initial_Menu(10, 3, WHITE, BLACK, 24, 0, 30);		//注册一个0级菜单
				Menu_Refresh_Flag = 0;
			}

			Draw_Option_Box(3, 0, 200, 30, 6, 30);							//注册选项框

			Action_Box_Up(3, 0, 200, 30, 6, 30); 					//添加选项框的上滑动作
			Action_Box_Down(3, 0, 200, 30, 6, 30); 					//添加选项框的下滑动作

			Button_Down_Click(6);										//注册down控制按钮
			Button_Up_Click(6);											//注册up控制按钮
			break;

		case 1:
			if (Menu_Refresh_Flag == 1)
			{
				Display_Second_Menu(10, 3, RED, BLACK, 32, 0, 59);			//注册一个1级菜单
				Menu_Refresh_Flag = 0;
			}

			Draw_Option_Box(3, 0, 150, 59, 4, 59);							//注册选项框

			Action_Box_Up(3, 0, 150, 59, 4, 59); 					//添加选项框的上滑动作
			Action_Box_Down(3, 0, 150, 59, 4, 59); 					//添加选项框的下滑动作

			Button_Down_Click(4);										//注册down控制按钮
			Button_Up_Click(4);											//注册up控制按钮
			break;

		case 2:
			if (Menu_Refresh_Flag == 1)
			{
				Display_Third_Menu();			//注册一个2级菜单
				Menu_Refresh_Flag = 0;
			}
			
			Draw_Option_Box(0, 0, 80, 79, 3, 79);							//注册选项框

			Action_Box_Up(0, 0, 80,79, 3, 79); 						//添加选项框的上滑动作
			Action_Box_Down(0, 0, 80, 79, 3, 79); 					//添加选项框的下滑动作

			Button_Down_Click(3);										//注册down控制按钮
			Button_Up_Click(3);											//注册up控制按钮
			break;

		default:
			Menu_Refresh_Flag = 0;
			break;
	}
}

